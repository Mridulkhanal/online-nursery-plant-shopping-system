<!-- admin/update_order.php: Update Order Status -->
<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../admin_login.php");
    exit();
}
include '../php/db_connect.php';

$order_id = $_GET['order_id'];
$status = $_GET['status'];

$sql = "UPDATE orders SET status = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $status, $order_id);
$stmt->execute();
$stmt->close();
$conn->close();

$_SESSION['success'] = "Order status updated to $status!";
header("Location: admin_orders.php");
?>