<!DOCTYPE html>
<footer>
    <p>© 2025 Online Nursery System. All rights reserved.</p>
</footer>
</body>
</html>
<link rel="stylesheet" href="../css/styles.css">